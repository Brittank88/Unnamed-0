// priority: 0

onEvent('event.recipes', event => {
    // Remove wireless heating recipes.
	event.remove({ id : 'ironfurnaces:heater'      });
	event.remove({ id : 'ironfurnaces:item_heater' });
});